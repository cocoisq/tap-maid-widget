戳戳小女僕 Android App + 桌面小工具

【App】
- 全螢幕角色畫面，點擊小女僕會播放擠壓動畫。
- 每次點擊播放你提供的橡膠玩具擠壓音效。
- 隨機顯示五句台詞：好了／不要點了／幹嘛／啊／哦鯨鯨。
- 顯示今日點擊次數。

【桌面小工具】
- 不用開啟 App，直接在手機主畫面點擊小女僕。
- 每次點擊播放音效、更新隨機台詞與今日次數。
- App 與桌面小工具共用同一份計數。
- 每天依手機當地時間 00:00 歸零；重新開機後會重新安排重置。
- 介面只保留角色、台詞與今日次數。

注意
- Android 桌面小工具由系統 RemoteViews 顯示，無法像 App 畫面一樣播放連續的自由變形動畫；完整擠壓動畫保留在 App 內。桌面小工具點擊仍會即時回饋台詞、音效與次數。
- Android 可能因省電模式稍微延後午夜鬧鐘；每次開啟 App、點擊或更新小工具時也會檢查日期並補正計數。

如何編譯 APK
1. 在電腦安裝 Android Studio。
2. 解壓縮本 ZIP，Android Studio 選擇 Open，開啟 TapMaidWidget 資料夾。
3. 等待 Gradle Sync，依提示安裝 Android SDK Platform 35 與 Build Tools。
4. 選單 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 位於 app/build/outputs/apk/debug/app-debug.apk。
6. 將 APK 傳到 Android 手機安裝；首次安裝可能要允許該來源安裝未知應用程式。
7. 開啟一次「戳戳小女僕」，然後長按主畫面空白處 > 小工具 > 戳戳小女僕，拖曳到主畫面。

建置備註
這是完整 Android Studio 原始專案。產生 APK 需要 Android SDK 與 Gradle 建置環境；目前執行環境未安裝 Android SDK/Gradle，故無法在此直接產生或驗證 APK。
