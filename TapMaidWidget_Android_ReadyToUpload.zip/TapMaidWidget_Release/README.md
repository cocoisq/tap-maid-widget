# 戳戳小女僕｜Android App + Home Screen Widget

這是 Android 原生版本的專案原始碼。App 內有點擊縮放動畫、音效、五種隨機反應與今日計數；桌面小工具顯示女僕、今日次數與反應，點擊後更新共用計數並播放音效。

## Build

GitHub Actions workflow: `.github/workflows/build-apk.yml`

成功後在 Actions → 對應 workflow run → Artifacts 下載 `tap-maid-debug-apk`，解壓後安裝 `app-debug.apk`。

## Notes

- Widget 使用 Android RemoteViews，因此桌面小工具提供點擊、文字更新與音效；完整縮放動畫在 App 內播放。
- 計數以裝置本地 SharedPreferences 儲存；依裝置當地日期換日歸零。午夜提醒使用非精確 AlarmManager，Android Doze 可能讓畫面更新稍微延後；每次點擊與開啟 App 時也會檢查日期。
- 目前為 debug APK，安裝時 Android 可能要求允許該來源安裝未知應用程式。
