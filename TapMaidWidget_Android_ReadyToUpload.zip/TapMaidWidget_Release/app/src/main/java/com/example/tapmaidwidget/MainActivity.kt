package com.example.tapmaidwidget

import android.app.Activity
import android.content.Context
import android.media.MediaPlayer
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var countView: TextView
    private lateinit var phraseView: TextView
    private lateinit var maidView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(237, 243, 255)
        window.navigationBarColor = Color.rgb(237, 243, 255)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(237, 243, 255))
            setPadding(dp(18), dp(14), dp(18), dp(18))
        }
        maidView = ImageView(this).apply {
            setImageResource(R.drawable.maid)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "戳一下小女僕"
            isClickable = true
            isFocusable = true
            setOnClickListener { onMaidTapped() }
        }
        root.addView(maidView, FrameLayout.LayoutParams(-1, -1))

        phraseView = TextView(this).apply {
            text = "戳我一下"
            textSize = 19f
            setTextColor(Color.rgb(64, 84, 125))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = pill(Color.WHITE, Color.rgb(185, 213, 244))
            elevation = dp(5).toFloat()
        }
        root.addView(phraseView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(8)
        })

        countView = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(9), dp(18), dp(9))
            background = pill(Color.rgb(89, 117, 174), Color.TRANSPARENT)
            elevation = dp(4).toFloat()
        }
        root.addView(countView, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(8)
        })

        setContentView(root)
        refreshCount()
    }

    private fun onMaidTapped() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayKey()
        val savedDay = prefs.getString(KEY_DAY, null)
        val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) + 1 else 1
        val previous = prefs.getInt(KEY_PHRASE_INDEX, -1)
        val next = if (previous in PHRASES.indices) {
            val n = Random.nextInt(PHRASES.size - 1)
            if (n >= previous) n + 1 else n
        } else Random.nextInt(PHRASES.size)

        prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, count)
            .putInt(KEY_PHRASE_INDEX, next).apply()
        phraseView.text = PHRASES[next]
        countView.text = "今日 $count 次"
        animateMaid()
        playSqueak()
        MaidWidgetProvider.refreshAll(this)
    }

    private fun refreshCount() {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayKey()
        val savedDay = prefs.getString(KEY_DAY, null)
        val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) else 0
        if (savedDay != today) prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, 0).apply()
        val phraseIndex = prefs.getInt(KEY_PHRASE_INDEX, -1)
        countView.text = "今日 $count 次"
        phraseView.text = if (phraseIndex in PHRASES.indices) PHRASES[phraseIndex] else "戳我一下"
        MaidWidgetProvider.scheduleNextMidnight(this)
        MaidWidgetProvider.refreshAll(this)
    }

    override fun onResume() {
        super.onResume()
        if (::countView.isInitialized) refreshCount()
    }

    private fun animateMaid() {
        maidView.clearAnimation()
        val squash = ScaleAnimation(
            1f, 1.10f, 1f, 0.82f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.82f
        ).apply {
            duration = 105
            repeatCount = 1
            repeatMode = Animation.REVERSE
            interpolator = android.view.animation.OvershootInterpolator(1.3f)
        }
        maidView.startAnimation(squash)
    }

    private fun playSqueak() {
        try {
            val player = MediaPlayer.create(this, R.raw.squeak) ?: return
            player.setOnCompletionListener { it.release() }
            player.setOnErrorListener { mp, _, _ -> mp.release(); true }
            player.start()
        } catch (_: Exception) { }
    }

    private fun pill(fill: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(28).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun todayKey() = SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())

    companion object {
        private const val PREFS = "maid_widget_prefs"
        private const val KEY_DAY = "day"
        private const val KEY_COUNT = "count"
        private const val KEY_PHRASE_INDEX = "phrase_index"
        private val PHRASES = listOf("好了", "不要點了", "幹嘛", "啊", "哦鯨鯨")
    }
}
