package com.example.tapmaidwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MaidWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refreshAll(context)
        scheduleNextMidnight(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TAP -> {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val today = todayKey()
                val savedDay = prefs.getString(KEY_DAY, null)
                val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) + 1 else 1
                val previous = prefs.getInt(KEY_PHRASE_INDEX, -1)
                val next = if (previous in PHRASES.indices) {
                    val n = Random.nextInt(PHRASES.size - 1)
                    if (n >= previous) n + 1 else n
                } else Random.nextInt(PHRASES.size)
                prefs.edit()
                    .putString(KEY_DAY, today)
                    .putInt(KEY_COUNT, count)
                    .putInt(KEY_PHRASE_INDEX, next)
                    .apply()
                playSqueak(context)
                refreshAll(context)
            }
            ACTION_RESET -> {
                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                prefs.edit().putString(KEY_DAY, todayKey()).putInt(KEY_COUNT, 0).apply()
                refreshAll(context)
                scheduleNextMidnight(context)
            }
        }
    }

    companion object {
        const val ACTION_TAP = "com.example.tapmaidwidget.ACTION_TAP"
        const val ACTION_RESET = "com.example.tapmaidwidget.ACTION_RESET"
        private const val PREFS = "maid_widget_prefs"
        private const val KEY_DAY = "day"
        private const val KEY_COUNT = "count"
        private const val KEY_PHRASE_INDEX = "phrase_index"
        private val PHRASES = listOf("好了", "不要點了", "幹嘛", "啊", "哦鯨鯨")

        fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.TAIWAN).format(Date())

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, MaidWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val today = todayKey()
            val savedDay = prefs.getString(KEY_DAY, null)
            val count = if (savedDay == today) prefs.getInt(KEY_COUNT, 0) else 0
            val phraseIndex = prefs.getInt(KEY_PHRASE_INDEX, -1)
            if (savedDay != today) {
                prefs.edit().putString(KEY_DAY, today).putInt(KEY_COUNT, 0).apply()
            }
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.maid_widget)
                views.setTextViewText(R.id.count_text, "今日 $count 次")
                views.setTextViewText(R.id.phrase_text, if (phraseIndex in PHRASES.indices) PHRASES[phraseIndex] else "戳我一下")
                val tapIntent = Intent(context, MaidWidgetProvider::class.java).apply { action = ACTION_TAP }
                val tapPending = PendingIntent.getBroadcast(
                    context, id, tapIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, tapPending)
                views.setOnClickPendingIntent(R.id.maid_image, tapPending)
                manager.updateAppWidget(id, views)
            }
        }

        fun scheduleNextMidnight(context: Context) {
            val next = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 2)
                set(Calendar.MILLISECOND, 0)
            }
            val intent = Intent(context, MaidWidgetProvider::class.java).apply { action = ACTION_RESET }
            val pending = PendingIntent.getBroadcast(
                context, 909, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // Inexact allow-while-idle alarm avoids requiring the special exact-alarm permission.
            // Android may defer it slightly during Doze; the date is also checked on every tap/update.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        }

        private fun playSqueak(context: Context) {
            try {
                val player = MediaPlayer.create(context, R.raw.squeak) ?: return
                player.setOnCompletionListener { it.release() }
                player.setOnErrorListener { mp, _, _ -> mp.release(); true }
                player.start()
            } catch (_: Exception) {
                // A failed sound must never prevent the widget counter from updating.
            }
        }
    }
}
